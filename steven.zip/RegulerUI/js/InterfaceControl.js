function GetChooseRobot(choice){
	ChooseRobot = choice;
	console.log(ChooseRobot);
}

