//
function showLabel(newValue, name, num) {
    document.getElementsByName(name)[num].innerText = newValue;
}
function showValue(newValue, name, num) {
    document.getElementsByName(name)[num].value = newValue;
}
 function rangeValue(newValue, name, num) {
     document.getElementsByName(name)[num].value = newValue;
 }

//======================================================================
