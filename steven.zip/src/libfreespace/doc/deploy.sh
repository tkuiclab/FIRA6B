#!/bin/bash
scp -r html/* libfreespace@libfreespace.hillcrestlabs.com:/mnt/appdata/www/libfreespace.hillcrestlabs.com/html/libfreespace/html/
