#include "motor_data.h"
/*
typedef struct{
	double	w1_speed;
	double	w2_speed;
	double	w3_speed;
	double	shoot;
}motor_command;
typedef struct{
	double	w1_theta;
	double 	w1_thetad;
	double	w2_theta;
	double 	w2_thetad;
	double	w3_theta;
	double 	w3_thetad;
}motor_feedback;

*/
/*
struct MOTOR_COMMAND{
	double w1_speed;
	double w2_speed;
	double w3_speed;
	int shoot;
};
struct MOTOR_FEEDBACK{
	double motor1_feedback;
	double motor2_feedback;
	double motor3_feedback;
};
*/
