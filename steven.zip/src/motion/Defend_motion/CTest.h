#include <iostream>

class CTEST{
public:
	CTEST(int argc, char **argv);
	~CTEST();

private:
	int member;
public:

	int testFunc();
};
