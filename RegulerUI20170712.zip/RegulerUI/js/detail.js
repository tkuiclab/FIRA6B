//=============================================================
//General
//SPlanningVelocity
$("td.GDetail")
$("td.SP1")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "單位:公尺\n啟動最大速度的最遠距離";
    });
$("td.SP2")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "單位:公尺\n啟動最小速度的最近距離";
    });
$("td.SP3")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "範圍:0~100\n最大速度";
    });
$("td.SP4")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "範圍:0~100\n最小速度";
    });
$("td.SP5")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "範圍:0~100\n最大角速度";
    });
$("td.SP6")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "範圍:0~100\n最小角速度";
    });
$("td.SP7")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "範圍:0~180\n啟動最大角速度的最大角度";
    });
$("td.SP8")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "範圍:0~180\n啟動最小角速度的最小角度";
    });
$("td.SP9")
    .mouseenter(function() {
        document.getElementById("GeneralDetail").innerText = "support的最小速度";
    });

//==================================================================================================================
//Pathplan
$("td.PathDetail")
//ZoneAttack
$("td.ZA1")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "單位:公尺\n離開球門的後退距離";
    });
$("td.ZA2")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "單位:公尺\n幹球門的前進距離";
    });
//Type-S Attack
$("td.PTSA1")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "擺動週期";
    });
$("td.PTSA2")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "最低速度";
    });
//Side Speed UP
$("td.PSSU1")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "繞球角度";
    });
$("td.PSSU2")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PSSU3")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PSSU4")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PSSU5")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
//Dorsad Attack
$("td.PDA1")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PDA2")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PDA3")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PDA4")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PDA5")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
$("td.PDA6")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "222";
    });
//Penalty Kick
$("td.PPK1")
    .mouseenter(function() {
        document.getElementById("PathplanDetail").innerText = "轉動方向\n1:右轉\n-1:左轉";
    });

//==================================================================================================================
//Behavior
$("td.BDetail")
//StateChase
$("td.BSC1")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
$("td.BSC2")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
$("td.BSC3")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
$("td.BSC4")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
$("td.BSC5")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
//StateAttack
$("td.BSA1")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "33";
    });
$("td.BSA2")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
$("td.BSA3")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
//StateSideSpeedUP
$("td.BSSSU1")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "123";
    });
$("td.BSSSU2")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "222";
    });
//StateZoneAttack
$("td.BSZA1")
    .mouseenter(function() {
        document.getElementById("BehaviorDetail").innerText = "4564";
    });